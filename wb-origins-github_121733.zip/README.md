# Water Builder: Origins

The official homepage for Water Builder: Origins — a single self-contained HTML file with:

- 🌊 YallToo-branded splash screen
- 🎮 Live playable Water Builder game (Baxter tutorial)
- 🎨 Engineering principles, journal, and CTA
- ⚡ Zero dependencies — pure HTML/CSS/JS

## View Live

Open `index.html` in any browser, or visit the GitHub Pages URL once enabled.

## Setup GitHub Pages

1. Go to **Settings** → **Pages**
2. Source: **Deploy from a branch** → `main` → `/ (root)`
3. Save — your site will be live at `https://YOUR-USERNAME.github.io/wb-origins/`

## Embed in Hostinger

Once live, embed in your Hostinger builder with an **iframe widget**:

```html
<iframe 
  src="https://YOUR-USERNAME.github.io/wb-origins/" 
  style="width:100%;height:1200px;border:0;"
  title="Water Builder: Origins">
</iframe>
```
