# Water Builder: Origins (Ship-It Pack v1.5)

🌊 **Live site:** https://jawa-dam.github.io/wb-origins/

## What's in the Ship-It Pack

1. **Tap-to-expand** (fullscreen button in stage)
2. **Settings cog** — modal with: sound toggle, animations toggle, water speed selector, reset progress
3. **Undo button** in the stage (auto-disables when no history)
4. **Achievement system** — 12 achievements with toast popups:
   - 💧 First Drop
   - 🎓 Hydraulic Engineer (tutorial done)
   - ⚡ Speed Demon (under 20s)
   - ✨ Less is More
   - 🏆 On Par (beat par)
   - ⭐ Veteran Builder (5 levels)
   - 👑 Master of the Watershed (all 11 levels)
   - ↩️ Second Thoughts (use undo)
   - 🌍 Explorer (3 mood switches)
   - 🎯 Triple Threat (farm + village + wheel)
   - 🎨 Perfectionist (5 undos in one level)
   - 🤫 Water Whisperer (exactly par)
5. **Local progress save** (checkmarks via levelCompleted record in localStorage)
6. **"Next level →" button** on the victory overlay
7. **5 more levels** (now 11 total: 1-1 through 3-2)
8. **Animated level intro** (camera pulse on the spring with particles)
9. **Streak counter** (🔥 X-day streak shown in the stage tag)
10. **Tooltips** on all the new controls

## Plus everything from before
- 8s splash with 5 spinning wooden gears + steam + hover-speedup
- Particle effects on water reaching goals
- Victory overlay with stats (drops, goals, time)
- Mobile-optimized stage (fixed height + bottom toolbar)
- Achievement popups

## Size
234 KB · 0 external requests
